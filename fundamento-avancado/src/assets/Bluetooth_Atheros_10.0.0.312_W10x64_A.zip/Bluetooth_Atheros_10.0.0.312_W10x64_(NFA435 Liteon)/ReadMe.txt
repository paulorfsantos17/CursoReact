==============================================================
Bluetooth Driver Package for Windows x64/x86 bit Win8.1/Win10
==============================================================

Bluetooth Driver Version
--------------
DriverVer   = 3.0.0.729 Win8.1 /10.0.0.312 Win10 
Tag = r10434.1

Adapters Supported
------------------
Qualcomm Atheros NFA344
Qualcomm Atheros NFA344A
Qualcomm Atheros NFA345
Qualcomm Atheros NFA435
Qualcomm Atheros NFA435A
Qualcomm Atheros NFA364A

  Please read the entire contents of this document. Information in this
  file may not appear in printed documentation or online help.

  This READ-ME file contains the following information:

        1.       INSTALLING Bluetooth DRIVER
        1.1     Menu-controlled Driver Installation
        1.2     Unattended Driver Installation
                
        2.      UNINSTALLING THE DRIVER

1. INSTALLING THE Bluetooth DRIVER
-------------------------------------

  Your computer system shipped pre-installed with the Bluetooth
  drivers for a Bluetooth adapter.

  For your convenience, the following procedures describe how to install
  the Bluetooth driver software.

  The Unattended Bluetooth Installation as described in 1.2 allows to
  install the drivers by a single command line. You can also set parameters for a
  'silent' installation (no messages displayed during the installation).

  NOTE: Before installing the Bluetooth driver, please close all open
        application programs and disable any anti-virus software
        running on your computer until the driver installation is
        complete! In addition, if you already have an Bluetooth driver installed,
        please uninstall the driver before installing another version of the
        driver.


1.1 Menu-controlled Bluetooth Driver Installation
---------------------------------------------

  1. Open the Bluetooth driver Setup.exe file to launch the Bluetooth
     InstallShield Wizard.

  2. Follow the instructions to complete the installation.


1.2 Unattended Bluetooth Driver Installation
----------------------------------------

  If you prefer to configure your system by command line editing you may
  install the Bluetooth drivers as follows:

  1. Go to the directory which contains the Bluetooth device driver

  2. Enter the following command:

     setup.exe /C:"install.exe /s /v/qn /v/norestart" /t:"c:\temp"




2. UNINSTALLING THE Bluetooth DRIVER SOFTWARE
--------------------------------------------------


2.1 Uninstalling Bluetooth Driver Software
----------------------------------------

  Note: It is highly recommended that you follow the steps in this section to
  completely uninstall the Bluetooth Driver software before updating to a new
  version of the software.
  Please reboot the system after driver install or uninstall process finish.

  Install Bluetooth driver with the setup.exe at the driver package.
  To uninstall the Bluetooth driver, follow these steps:

  1. From the Windows taskbar, click Start > Control Panel to open the
     Control Panel window.

  2. Doubleclick Programs -> uninstall a program.

  3. Click the Bluetooth Driver item from the list.

  4. Click Uninstall/Change.

  5. Follow the prompts to finish driver uninstallation.


================================================================================
